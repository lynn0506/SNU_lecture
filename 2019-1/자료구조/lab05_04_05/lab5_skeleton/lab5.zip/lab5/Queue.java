import java.util.Stack;

public class Queue {

    private Stack<Integer> s1 = new Stack<Integer>();
    private Stack<Integer> s2 = new Stack<Integer>();

    public void enQueue(int x) {

    }

    public int deQueue() {
        return 0;
    }
}
