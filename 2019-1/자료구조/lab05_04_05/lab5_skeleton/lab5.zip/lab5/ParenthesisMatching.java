import java.util.Stack;

public class ParenthesisMatching {


    /**
     * output the matched parenthesis pairs in the string expr
     */
    public static void printMatchedPairs(String expr) {




    }



}


